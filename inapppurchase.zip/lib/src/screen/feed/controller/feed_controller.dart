import 'package:english_madhyam/main.dart';
import 'package:english_madhyam/src/helper/model/feed_model/feed_model.dart';
import 'package:english_madhyam/src/screen/feed/model/evnetFeedModel.dart';
import 'package:flutter/animation.dart';
import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';
import 'package:fluttertoast/fluttertoast.dart';

import '../../../../api_repository/api_service.dart';

class FeedController extends GetxController
    with GetSingleTickerProviderStateMixin {
  var loading = true.obs;
  var wordOfDayList =<WordOfDay>[].obs;
  var phraseList =<Phrase>[].obs;

 // Rx<FeedModel> feeds = FeedModel().obs;
  late AnimationController _feedAnimation;
  late Animation _animation;
  Animation get animation => _animation;
  late PageController _pageController;
  PageController get pageController => _pageController;

  //var isFirstLoadRunning = false.obs;
  var isLoadMoreRunning = false.obs;
  late bool hasNextPage;
  //late int _pageNumber;
  int pageNumber = 1;
  ScrollController scrollController = ScrollController();


  @override
  void onInit() async {
    _feedAnimation =
        AnimationController(vsync: this, duration: const Duration(seconds: 8));
    _animation = Tween<double>(begin: 0, end: 1).animate(_feedAnimation)
      ..addListener(() {
        update();
      });
    _pageController = PageController();
    _feedAnimation.forward();
    super.onInit();
  }

  //
  Future<void> feedApiFetch(
      {required String type, required String date}) async {
    try {
      loading(true);
      FeedModel? response = await apiService.getFeed(type: type, date: date);
      loading(false);
      if (response != null) {
        if(type=="word" && response.data?.wordOfDay!=null){
          wordOfDayList.clear();
          wordOfDayList.addAll(response.data!.wordOfDay!);
        }else{
          phraseList.clear();
          phraseList.addAll(response.data?.phrase??[]);
        }
      }
    } catch (e) {
      loading(false);
    }
    finally{
      loading(false);
    }
  }


  //start
  Future<void> getFeedListApi(
      {required bool isRefresh}) async {
    pageNumber=1;
    if (!isRefresh) {
      loading(true);
    }
    EventFeedModel? model =
    await apiService.getFeedPagination(page: pageNumber,);
    if (model!.result == true) {
      wordOfDayList.clear();
      wordOfDayList.addAll(model.data?.wordOfDay?.eventData??[]);
      if(model.data?.wordOfDay?.total!=null && pageNumber < model.data!.wordOfDay!.total!){
        pageNumber = pageNumber + 1;
        hasNextPage = true;
      }else{
        hasNextPage = false;
      }
      if (hasNextPage) {
        //getPracticeChildLoadMore();
      }
      loading(false);
    } else {
      loading(false);
    }
  }

  Future<void> getPracticeChildLoadMore() async {
    pageController.addListener(() async {
      if (hasNextPage == true &&
          loading.value == false &&
          isLoadMoreRunning.value == false &&
          pageController.position.maxScrollExtent ==
              pageController.position.pixels) {
        isLoadMoreRunning(true);
        try {
          EventFeedModel? model =
          await apiService.getFeedPagination(page: pageNumber);
          if (model!.result == true) {
            if(model.data?.wordOfDay?.total!=null && pageNumber < model.data!.wordOfDay!.total!){
              pageNumber = pageNumber + 1;
              hasNextPage = true;
            }else{
              hasNextPage = false;
            }
            print("has next page$hasNextPage");
            wordOfDayList.addAll(model.data?.wordOfDay?.eventData??[]);
            update();
          }
        } catch (e) {
          print(e.toString());
        }
        isLoadMoreRunning(false);
      }
    });
  }
//end

}
