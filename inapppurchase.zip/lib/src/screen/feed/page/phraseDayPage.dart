import 'dart:ui';
import 'package:english_madhyam/src/helper/bindings/feed_bindings/feed_bind.dart';
import 'package:english_madhyam/src/screen/feed/controller/feed_controller.dart';
import 'package:english_madhyam/src/utils/colors/colors.dart';
import 'package:english_madhyam/src/screen/pages/page/custom_dmsans.dart';
import 'package:flutter/material.dart';
import 'package:flutter_html/flutter_html.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:get/get.dart';
import 'package:lottie/lottie.dart';
import 'package:intl/intl.dart';

import '../../../../helper/loading.dart';
import '../../pages/page/converter.dart';

class PhraseDayPge extends StatefulWidget {
  const PhraseDayPge({Key? key}) : super(key: key);

  @override
  _PhraseDayPgeState createState() => _PhraseDayPgeState();
}

class _PhraseDayPgeState extends State<PhraseDayPge> {
  final HtmlConverter _htmlConverter = HtmlConverter();
  String FormattedDate = "";

  @override
  void initState() {
    // TODO: implement initState
    FeedBinding();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: purpleColor.withOpacity(0.001),
        body: SizedBox(
          height: MediaQuery.of(context).size.height,
          width: MediaQuery.of(context).size.width,
          child: GetX<FeedController>(
            init: FeedController(),
            builder: (controller) {
             return Stack(
               children: [
                 controller.phraseList.isEmpty
                     ? Column(
                   mainAxisAlignment: MainAxisAlignment.center,
                   children: [
                     Center(
                       child: Lottie.asset(
                           'assets/animations/49993-search.json',
                           height:
                           MediaQuery.of(context).size.height * 0.15),
                     ),
                     CustomDmSans(text: "No Phrases Today")
                   ],
                 )
                     : PageView.builder(
                     controller: controller.pageController,
                     // onPageChanged: controller.,
                     scrollDirection: Axis.vertical,
                     // physics: NeverScrollableScrollPhysics(),
                     itemCount: controller.phraseList.length,
                     itemBuilder: (BuildContext ctx, int index) {
                       FormattedDate = DateFormat("MMM -d-y").format(
                           DateTime.parse(controller.phraseList[index].date!));
                       String htmlMean = _htmlConverter.parseHtmlString(
                           controller.phraseList[index].meaning
                               .toString());

                       return Padding(
                         padding: const EdgeInsets.all(20.0),
                         child: SingleChildScrollView(
                           child: Column(
                             children: [
                               const SizedBox(height: 8),
                               Text(
                                 FormattedDate,
                                 style: GoogleFonts.raleway(
                                     fontSize: 12,
                                     color: darkGreyColor,
                                     fontWeight: FontWeight.w700),
                               ),
                               const SizedBox(height: 8),
                               Text(
                                 controller.phraseList[index].word
                                     .toString(),
                                 style: GoogleFonts.raleway(
                                   fontSize: 24,
                                   fontWeight: FontWeight.w600,
                                 ),
                               ),
                               const SizedBox(height: 20),
                               Container(
                                 height:
                                 MediaQuery.of(context).size.height * 0.25,
                                 width:
                                 MediaQuery.of(context).size.width * 0.9,
                                 decoration: BoxDecoration(
                                     borderRadius: BorderRadius.circular(6),
                                     image:controller.phraseList[index].image !=
                                         null
                                         ? DecorationImage(
                                         image: NetworkImage(
                                           controller.phraseList[index].image
                                               .toString(),
                                         ),
                                         fit: BoxFit.cover)
                                         : const DecorationImage(
                                         image: AssetImage(
                                             "assets/img/phraseee.png"),
                                         fit: BoxFit.cover),
                                     boxShadow: [
                                       BoxShadow(
                                           blurRadius: 2,
                                           color: greyColor.withOpacity(0.6),
                                           spreadRadius: 2,
                                           offset: const Offset(1, 4))
                                     ]),
                               ),
                               const SizedBox(height: 20),
                               Container(
                                 padding: const EdgeInsets.all(5),
                                 height:
                                 MediaQuery.of(context).size.height * 0.3,
                                 decoration: BoxDecoration(
                                     color: const Color(0xffccccff)
                                         .withOpacity(0.6),
                                     borderRadius: BorderRadius.circular(4),
                                     boxShadow: [
                                       BoxShadow(
                                           color: greyColor.withOpacity(0.2),
                                           offset: const Offset(2, 4),
                                           spreadRadius: 3,
                                           blurRadius: 2)
                                     ]),
                                 child: Scrollbar(
                                   thumbVisibility: true,
                                   thickness: 5.0,
                                   trackVisibility: true,
                                   radius: const Radius.circular(12),
                                   child: ListView(
                                     shrinkWrap: true,
                                     children: [
                                       Center(
                                           child: Container(
                                               decoration: BoxDecoration(
                                                   borderRadius:
                                                   BorderRadius.circular(
                                                       4),
                                                   color: purpleColor
                                                       .withOpacity(0.4)),
                                               padding:
                                               const EdgeInsets.all(2),
                                               child: CustomDmSans(
                                                 text: "Scroll Down",
                                                 fontSize: 10,
                                               ))),
                                       Wrap(
                                         children: [
                                           Row(
                                             crossAxisAlignment:
                                             CrossAxisAlignment.start,
                                             children: [
                                               SizedBox(
                                                 width: MediaQuery.of(context)
                                                     .size
                                                     .width *
                                                     0.25,
                                                 child: Text("Phrase:  ",
                                                     style:
                                                     GoogleFonts.raleway(
                                                         fontSize: 16,
                                                         color: blackColor,
                                                         fontWeight:
                                                         FontWeight
                                                             .w600)),
                                               ),
                                               Expanded(
                                                 child: Text(
                                                     controller.phraseList[index]
                                                         .word!,
                                                     style:
                                                     GoogleFonts.raleway(
                                                       fontSize: 16,
                                                       color: blackColor,
                                                     )),
                                               ),
                                             ],
                                           ),
                                         ],
                                       ),
                                       Wrap(
                                         children: [
                                           Row(
                                             crossAxisAlignment:
                                             CrossAxisAlignment.start,
                                             children: [
                                               SizedBox(
                                                 width: MediaQuery.of(context)
                                                     .size
                                                     .width *
                                                     0.25,
                                                 child: Text("Meaning:  ",
                                                     style:
                                                     GoogleFonts.raleway(
                                                         fontSize: 16,
                                                         color: blackColor,
                                                         fontWeight:
                                                         FontWeight
                                                             .w600)),
                                               ),
                                               Expanded(
                                                 child: Html(
                                                   data: htmlMean,
                                                   style: {
                                                     "body": Style(
                                                         fontSize: FontSize(18.0),fontWeight: FontWeight.w300,
                                                       color: blackColor
                                                     ),
                                                   },
                                                 )/*Text(htmlMean,
                                                     style:
                                                     GoogleFonts.raleway(
                                                       fontSize: 16,
                                                       color: blackColor,
                                                     ))*/,
                                               ),
                                             ],
                                           ),
                                         ],
                                       ),
                                     ],
                                   ),
                                 ),
                               ),
                             ],
                           ),
                         ),
                       );
                     }),
                 controller.loading.value?const Loading():const SizedBox()
               ],
             );
            },
          ),
        ));
  }
}
