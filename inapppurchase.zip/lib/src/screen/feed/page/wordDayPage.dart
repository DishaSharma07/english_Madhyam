import 'dart:ui';
import 'package:english_madhyam/helper/loading.dart';
import 'package:english_madhyam/src/helper/bindings/feed_bindings/feed_bind.dart';
import 'package:english_madhyam/src/screen/feed/controller/feed_controller.dart';
import 'package:english_madhyam/src/utils/colors/colors.dart';
import 'package:english_madhyam/src/screen/pages/page/custom_dmsans.dart';
import 'package:flutter/material.dart';
import 'package:flutter_html/flutter_html.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:get/get.dart';
import 'package:lottie/lottie.dart';
import 'package:intl/intl.dart';

import '../../pages/page/converter.dart';

class WordDayPage extends StatefulWidget {
  const WordDayPage({Key? key}) : super(key: key);

  @override
  _WordDayPageState createState() => _WordDayPageState();
}

class _WordDayPageState extends State<WordDayPage> {

final HtmlConverter _htmlConverter=HtmlConverter();
String FormattedDate="";


  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: purpleColor.withOpacity(0.001),
        body:SizedBox(
          height: MediaQuery.of(context).size.height ,
          width: MediaQuery.of(context).size.width,
          child: GetX<FeedController>(
            init: FeedController(),
            builder: (controller) {
              return Stack(
                children: [
                  controller.wordOfDayList.isEmpty
                      ?  Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Center(
                        child: Lottie.asset(
                            'assets/animations/49993-search.json',
                            height:
                            MediaQuery.of(context).size.height * 0.15),
                      ),
                      CustomDmSans(text: "No Words Today")
                    ],
                  )
                      : PageView.builder(
                      controller: controller.pageController,
                      // onPageChanged: controller.,
                      scrollDirection: Axis.vertical,
                      // physics: NeverScrollableScrollPhysics(),
                      itemCount: controller.wordOfDayList.length,
                      itemBuilder: (BuildContext ctx, int index) {
                        var wordDay=controller.wordOfDayList[index];
                        FormattedDate=DateFormat("MMM -d-y").format(DateTime.parse(wordDay.date!));
                        String htmlMean=_htmlConverter.parseHtmlString(wordDay.meaning.toString());
                        String htmlSnoym=_htmlConverter.parseHtmlString(wordDay.synonyms.toString());
                        String htmlAntonym=_htmlConverter.parseHtmlString(wordDay.antonyms.toString());
                        String htmlExample=_htmlConverter.parseHtmlString(wordDay.example.toString());
                        return Padding(
                          padding: const EdgeInsets.all(20.0),
                          child: SingleChildScrollView(
                            child: Column(
                              children: [
                                const SizedBox(height: 8),
                                Text(
                                  FormattedDate,
                                  style: GoogleFonts.raleway(
                                      fontSize: 12,
                                      color: darkGreyColor,
                                      fontWeight: FontWeight.w700
                                  ),
                                ),
                                const SizedBox(height: 8),
                                Text(
                                  controller.wordOfDayList[index].word.toString(),
                                  style: GoogleFonts.raleway(
                                    fontSize: 24,
                                    fontWeight: FontWeight.w600,
                                  ),
                                ),
                                const SizedBox(height: 20),
                                Container(
                                  height:
                                  MediaQuery.of(context).size.height * 0.25,
                                  width: MediaQuery.of(context).size.width*0.9,
                                  decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(6),
                                      image: controller.wordOfDayList[index].image!=null?DecorationImage(
                                          image: NetworkImage(controller.wordOfDayList[index].image.toString(),),
                                          fit: BoxFit.cover
                                      ):const DecorationImage(
                                          image: AssetImage("assets/img/word.jpg"),
                                          fit: BoxFit.cover
                                      ),
                                      boxShadow: [
                                        BoxShadow(
                                            blurRadius: 2,
                                            color: greyColor.withOpacity(0.6),
                                            spreadRadius: 2,
                                            offset: const Offset(1,4)
                                        )
                                      ]
                                  ),
                                ),
                                const SizedBox(height: 20),
                                Container(
                                  padding: const EdgeInsets.only(top: 5,left: 5,right: 5,bottom: 30),
                                  height: MediaQuery.of(context).size.height*0.3,
                                  decoration: BoxDecoration(
                                      color: const Color(0xffccccff).withOpacity(0.6),
                                      borderRadius: BorderRadius.circular(4),
                                      boxShadow: [
                                        BoxShadow(
                                            color: greyColor.withOpacity(0.2),
                                            offset:const Offset(2, 4),
                                            spreadRadius: 3,
                                            blurRadius: 2
                                        )
                                      ]
                                  ),
                                  child: Scrollbar(
                                    thumbVisibility: true,
                                    thickness: 5.0,
                                    trackVisibility: true,
                                    radius:const Radius.circular(12),
                                    child: ListView(
                                      shrinkWrap: true,
                                      children: [
                                        Center(child: Container(
                                            decoration: BoxDecoration(
                                                borderRadius: BorderRadius.circular(4),
                                                color: purpleColor.withOpacity(0.4)
                                            ),
                                            padding:const EdgeInsets.all(2),
                                            child: CustomDmSans(text: "Scroll Down",fontSize: 10,))),
                                        htmlMean=="null"?const SizedBox():Wrap(

                                          children: [
                                            Row(
                                              crossAxisAlignment: CrossAxisAlignment.start,
                                              children: [
                                                SizedBox(
                                                  width: MediaQuery.of(context).size.width * 0.25,
                                                  child: Text("Meaning:  ",
                                                      style: GoogleFonts.raleway(
                                                          fontSize: 16,
                                                          color: blackColor,
                                                          fontWeight: FontWeight.w600)),
                                                ),
                                                Expanded(
                                                  child: Text(
                                                      htmlMean,
                                                      style: GoogleFonts.raleway(
                                                        fontSize: 16,
                                                        color: blackColor,
                                                      )),
                                                ),
                                              ],
                                            ),
                                          ],
                                        ),
                                        htmlSnoym=="null"?const SizedBox():Wrap(

                                          children: [
                                            Row(
                                              crossAxisAlignment: CrossAxisAlignment.start,
                                              children: [
                                                SizedBox(
                                                  width: MediaQuery.of(context).size.width * 0.25,
                                                  child: Text("Synonyms:  ",
                                                      style: GoogleFonts.raleway(
                                                          fontSize: 16,
                                                          color: blackColor,
                                                          fontWeight: FontWeight.w600)),
                                                ),
                                                Expanded(

                                                  child: Html(
                                                    data: htmlSnoym,
                                                    style: {
                                                      "body": Style(
                                                          fontSize: FontSize(16.0),fontWeight: FontWeight.w300,
                                                          color: blackColor
                                                      ),
                                                    },
                                                  )/*Text(
                                                      htmlSnoym,
                                                      style: GoogleFonts.raleway(
                                                        fontSize: 16,
                                                        color: blackColor,
                                                      ))*/,
                                                ),
                                              ],
                                            ),
                                          ],
                                        ),
                                        const SizedBox(height: 20),
                                        htmlAntonym=="null"?const SizedBox():Wrap  (
                                          children: [
                                            Row(
                                              crossAxisAlignment: CrossAxisAlignment.start,
                                              children: [
                                                SizedBox(
                                                  width: MediaQuery.of(context).size.width * 0.25,
                                                  child: Text("Antonyms:  ",
                                                      style: GoogleFonts.raleway(
                                                          fontSize: 16,
                                                          color: blackColor,
                                                          fontWeight: FontWeight.w600)),
                                                ),
                                                Expanded(
                                                  child: Html(
                                                    data: htmlAntonym,
                                                    style: {
                                                      "body": Style(
                                                          fontSize: FontSize(16.0),fontWeight: FontWeight.w300,
                                                          color: blackColor
                                                      ),
                                                    },
                                                  )/*Text(
                                                      htmlAntonym,
                                                      style: GoogleFonts.raleway(
                                                        fontSize: 16,
                                                        color: blackColor,
                                                      ))*/,
                                                ),
                                              ],
                                            ),
                                          ],
                                        ),
                                        const SizedBox(height: 20),
                                        htmlExample=="null"?const SizedBox():Wrap  (
                                          children: [
                                            Row(
                                              crossAxisAlignment: CrossAxisAlignment.start,
                                              children: [
                                                SizedBox(
                                                  width: MediaQuery.of(context).size.width * 0.25,
                                                  child: Text("Examples:  ",
                                                      style: GoogleFonts.raleway(
                                                          fontSize: 16,
                                                          color: blackColor,
                                                          fontWeight: FontWeight.w600)),
                                                ),
                                                Expanded(
                                                  child: Html(
                                                    data: htmlExample,
                                                    style: {
                                                      "body": Style(
                                                          fontSize: FontSize(16.0),fontWeight: FontWeight.w300,
                                                          color: blackColor
                                                      ),
                                                    },
                                                  )/*Text(
                                                      htmlExample,
                                                      style: GoogleFonts.raleway(
                                                        fontSize: 16,
                                                        color: blackColor,
                                                      ))*/,
                                                ),
                                              ],
                                            ),
                                          ],
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        );
                      }),
                  controller.loading.value?const Loading():const SizedBox()
                ],
              );
            },
          ),
        ));
  }
}
