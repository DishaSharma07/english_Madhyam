import 'package:english_madhyam/helper/app_colors.dart';
import 'package:english_madhyam/helper/loading.dart';
import 'package:english_madhyam/src/custom/semiBoldTextView.dart';
import 'package:english_madhyam/src/custom/toolbarTitle.dart';
import 'package:english_madhyam/src/screen/favorite/controller/favoriteController.dart';
import 'package:english_madhyam/src/screen/favorite/model/questionDataModel.dart';
import 'package:flutter/material.dart';
import 'package:flutter_html/flutter_html.dart';
import 'package:get/get.dart';
import 'package:pull_to_refresh/pull_to_refresh.dart';
import '../../../../helper/regularTextView.dart';
import '../../../utils/colors/colors.dart';
import '../../pages/page/converter.dart';
import '../../pages/page/custom_dmsans.dart';

class SaveQuestionList extends GetView<FavoriteController> {
  static const name = "SaveQuestionList";
  SaveQuestionList({Key? key}) : super(key: key);

  final FavoriteController favoriteController = Get.find();
  final RefreshController _refreshController =
      RefreshController(initialRefresh: false);
  final HtmlConverter _htmlConverter = HtmlConverter();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const ToolbarTitle(title: "My Questions"),
      ),
      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: GetX<FavoriteController>(builder: (contr) {
          return Stack(
            children: [
              listBodyWidget(saveWordsList: contr.saveQuestionList),
              contr.loading.value ? const Loading() : const SizedBox(),
              !contr.loading.value && contr.saveQuestionList.isEmpty
                  ? const Center(
                      child: Text("No Data Found"),
                    )
                  : const SizedBox()
            ],
          );
        }),
      ),
    );
  }

  Widget listBodyWidget({required List<dynamic> saveWordsList}) {
    return SmartRefresher(
      controller: _refreshController,
      onRefresh: _onRefresh,
      child: ListView.builder(
          physics: const AlwaysScrollableScrollPhysics(),
          itemCount: saveWordsList.length,
          itemBuilder: (context, index) {
            QuestionData wordData = saveWordsList[index];
            return Card(
              elevation: 5,
              margin: const EdgeInsets.only(
                  left: 10, right: 10, bottom: 5, top: 10),
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(5)),
              child: Padding(
                  padding: const EdgeInsets.all(10.0),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      ListTile(
                        title: Html(
                          data: wordData.eQuestion.toString(),
                          style: {
                            "body": Style(
                              fontSize: FontSize(18.0),
                            ),
                            "p": Style(fontSize: FontSize(18.0))
                          },
                        ),
                        trailing: GestureDetector(
                          onTap: () async {
                            await controller.removeQuestionFromList(
                                context: context,
                                questionId: wordData.id.toString() ?? "");
                            saveWordsList.removeAt(index);
                            controller.update();
                          },
                          child: const Padding(
                            padding: EdgeInsets.all(8.0),
                            child: Icon(
                              Icons.bookmark,
                              color: primaryColor,
                            ),
                          ),
                        ),
                      ),
                      optionBody(wordData.options ?? []),
                      CustomDmSans(
                        text: "Solutions :",
                        color: greenColor,
                      ),
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Html(
                          data: wordData.solutions!.eSolutions ?? "",
                          style: {
                            "body": Style(
                              fontSize: FontSize(14.0),
                            ),
                            "p": Style(fontSize: FontSize(16.0))
                          },
                        ),
                      ),
                    ],
                  )),
            );
          }),
    );
  }

  Widget optionBody(List<Options> optionsList) {
    return Container(
        margin: const EdgeInsets.only(top: 10),
        padding: const EdgeInsets.only(left: 5, right: 5),
        child: ListView.builder(
            physics: const NeverScrollableScrollPhysics(),
            shrinkWrap: true,
            itemCount: optionsList.length,
            itemBuilder: (context, index) {
              Options optionData = optionsList[index];
              return Container(
                  margin: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                      boxShadow: [
                        BoxShadow(
                          color: optionData.correct == 1
                              ? lightGreenColor
                              : Colors.grey,
                          offset: const Offset(0.0, 1.0), //(x,y)
                          blurRadius: 4.0,
                        ),
                      ],
                      border: Border.all(
                          color:
                              optionData.correct == 1 ? greenColor : whiteColor,
                          width: 2),
                      color: whiteColor,
                      borderRadius: BorderRadius.circular(10)),
                  padding: const EdgeInsets.only(
                      left: 10, top: 5, bottom: 5, right: 10),
                  child: Container(
                      padding: const EdgeInsets.all(8),
                      child: RegularTextDarkMode(
                        text: _htmlConverter.removeAllHtmlTags(
                          optionData.optionE.toString(),
                        ),textAlign: TextAlign.start,)),);
            }));
  }

  void _onRefresh() async {
    // monitor network fetch
    favoriteController.getSaveQuestionList();

    await Future.delayed(const Duration(milliseconds: 1000));
    // if failed,use refreshFailed()
    _refreshController.refreshCompleted();
  }
}

