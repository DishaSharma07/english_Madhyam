import 'package:english_madhyam/src/helper/model/pdf_list_model.dart';
import 'package:get/get.dart';

import '../../../../api_repository/api_service.dart';

class PdfController extends GetxController {
  RxBool loading = false.obs;
  Rx<PdfList> pdfList = PdfList().obs;


  void pdfListController({required String type, required String id}) async {
    try {
      loading(true);
      var response = await apiService.pdfListProv(type:type, id: id);
      loading(false);
      if (response != null) {
        pdfList.value = response;
      } else {
        return null;
      }
    } catch (e) {
      print(e.toString());
    } finally {
      loading(false);
    }
  }
}
